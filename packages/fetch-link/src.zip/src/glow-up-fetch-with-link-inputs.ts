import {adaptFetchInputs} from '@windyroad/adapt-fetch-inputs';
import {isLink, type Link} from './link.js';
import {type LinkedResponse} from './linked-response.js';

/**
 * Checks if a Headers object is empty.
 * @param headers The Headers object to check.
 * @returns True if the Headers object is empty, false otherwise.
 */
function isHeadersEmpty(headers: Headers): boolean {
	let isEmpty = true;
	// eslint-disable-next-line no-unreachable-loop
	for (const _header of headers) {
		isEmpty = false;
		break;
	}

	return isEmpty;
}

type DropFirst<T extends unknown[]> = T extends [any, ...infer U] ? U : never;

/**
 * Adapts the fetch API to work with RFC8288 Link objects.
 * @template FetchReturns - The return type of the original fetch function.
 * @param {Function} fetchImpl - The original fetch function to adapt.
 * @returns {Function} An adapted fetch function that supports passing in a Link object.
 */
export function glowUpFetchWithLinkInputs<
	FetchImpl extends (
		...args: Parameters<typeof fetch>
	) => Promise<any> = typeof fetch,
>(
	fetchImpl?: FetchImpl,
): (
	target: Link | Parameters<FetchImpl>[0],
	...init: DropFirst<Parameters<FetchImpl>>
) => ReturnType<FetchImpl> {
	const adapter = (
		target: Link | Parameters<FetchImpl>[0],
		...other: DropFirst<Parameters<FetchImpl>>
	): Parameters<FetchImpl> => {
		if (isLink(target)) {
			const link = target;
			const [init, ...remainder] = other;

			const headers = new Headers(init?.headers ?? {});
			// Only set the 'Accept' header if link.type is defined.
			if (link.type) {
				headers.append('Accept', link.type);
			}

			if (link.hreflang) {
				headers.append('Accept-Language', link.hreflang);
			}

			const fetchParameters = [
				link.uri,
				{
					...init,
					...(link.method && {method: link.method}),
					...(!isHeadersEmpty(headers) && {headers}),
				},
				...remainder,
			];
			return fetchParameters;
		}

		return [target, ...other];
	};

	return adaptFetchInputs<
		FetchImpl,
		[Link | Parameters<FetchImpl>[0], ...DropFirst<Parameters<FetchImpl>>]
	>(adapter, fetchImpl);
}
