import {type Link} from './link.js';
import {decorateFetchResponseWithLinks} from './decorate-fetch-response-with-links.js';
import {type LinkedResponse} from './linked-response.js';
import {glowUpFetchWithLinkInputs} from './glow-up-fetch-with-link-inputs.js';

/**
 * Adapts the fetch API to work with RFC8288 Link objects.
 * @template FetchReturns - The return type of the original fetch function.
 * @param {Function} fetchImpl - The original fetch function to adapt.
 * @returns {Function} An adapted fetch function that supports passing in a Link object.
 */
export function glowUpFetchWithLinks<
	FetchReturns extends Pick<Response, 'headers'> = Awaited<
		ReturnType<typeof fetch>
	>,
>(
	fetchImpl?: (...args: Parameters<typeof fetch>) => Promise<FetchReturns>,
): (
	target: Link | Parameters<typeof fetch>[0],
	init?: Parameters<typeof fetch>[1],
) => Promise<LinkedResponse<FetchReturns>> {
	return glowUpFetchWithLinkInputs(decorateFetchResponseWithLinks(fetchImpl));
}
